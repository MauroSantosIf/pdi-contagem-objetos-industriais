# detecção parafusos Anderson > 2025-12-01 1:07pm
https://universe.roboflow.com/parafusosia/deteccao-parafusos-anderson-qjja5

Provided by a Roboflow user
License: CC BY 4.0


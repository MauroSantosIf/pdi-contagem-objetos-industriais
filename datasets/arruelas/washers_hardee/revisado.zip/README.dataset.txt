# Washers > 2022-03-14 5:43pm
https://universe.roboflow.com/hardee/washers-o8mxn

Provided by a Roboflow user
License: CC BY 4.0


# Screws and nuts > First version of screws and nuts
https://universe.roboflow.com/zians-workspace/screws-and-nuts-k7why

Provided by a Roboflow user
License: CC BY 4.0


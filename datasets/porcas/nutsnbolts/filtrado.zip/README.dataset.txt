# NutsNBolts > 2025-12-14 5:40pm
https://universe.roboflow.com/tktk-hodc3/nutsnbolts

Provided by a Roboflow user
License: CC BY 4.0

